'use client';

import { useState } from 'react';
import StockPriceForm from './stock-price-form';
import TransactionForm from './transaction-form';
import TransactionList from './transaction-list';
import { fetchPortfolioSummary } from '../services/portfolio';
import { useEffect, useState } from 'react';

export default function PortfolioHome() {
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    (async () => {
      try {
        const data = await fetchPortfolioSummary();
        setSummary(data);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div style={{ maxWidth: 900, margin: '2rem auto', padding: '1rem' }}>
      <h1>Bolsa de Valores</h1>

      {/* Resumo do Patrimônio */}
      <section>
        <h2>Resumo do Patrimônio</h2>
        {loading && <p>Carregando...</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {summary && (
          <div>
            <p>
              Total: R${summary.patrimonio_total?.toLocaleString('pt-BR')}
            </p>
            <p>
              Rentabilidade Mensal: {summary.rentabilidade_mes_percentual}%
            </p>
            <p>
              Distribuição de Risco:
              {summary.distribuicao?.renda_variavel}% Renda Variável,
              {summary.distribuicao?.renda_fixa}% Renda Fixa
            </p>
          </div>
        )}
      </section>

      {/* Formulário de Cotação de Ações */}
      <section>
        <h2>Cotação de Ações</h2>
        <StockPriceForm />
      </section>

      {/* Formulário de Transação */}
      <section>
        <h2>Nova Transação</h2>
        <TransactionForm />
      </section>

      {/* Lista de Transações Recentes */}
      <section>
        <h2>Transações Recentes</h2>
        <TransactionList />
      </section>
    </div>
  );
}