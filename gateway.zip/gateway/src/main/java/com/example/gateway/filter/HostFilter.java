package com.example.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;
import org.springframework.core.Ordered;

/**
 * Allows requests only from the host {@code frontend.example.com}.
 * Any other Host header value receives a 403 Forbidden response.
 */
@Component
public class HostFilter implements GatewayFilter, Ordered {

    private static final String ALLOWED_HOST = "frontend.example.com";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String host = exchange.getRequest().getHeaders().getFirst(HttpHeaders.HOST);

        if (host == null || !host.contains(ALLOWED_HOST)) {
            exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
            return exchange.getResponse().setComplete();
        }
        return chain.filter(exchange);
    }

    @Override
    public int getOrder() {
        return HIGHEST_PRECEDENCE;
    }
}