package com.example.gateway;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.io.IOException;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient(timeout = "5000")
class HostFilterIntegrationTest {

    private static MockWebServer mockBackEnd;

    @Autowired
    private WebTestClient webTestClient;

    private static final String ALLOWED_HOST = "frontend.example.com";

    @BeforeAll
    static void setUp() throws IOException {
        mockBackEnd = new MockWebServer();
        mockBackEnd.start();
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockBackEnd.shutdown();
    }

    @DynamicPropertySource
    static void registerProperties(DynamicPropertyRegistry registry) {
        // Faz o Gateway apontar para o nosso servidor fake durante o teste
        registry.add("CORE_SERVICE_URL", () -> "http://localhost:" + mockBackEnd.getPort());
    }

    @Test
    void whenHostIsAllowed_thenRequestIsForwarded() {
        mockBackEnd.enqueue(new MockResponse().setResponseCode(200).setBody("ok"));

        webTestClient.get()
                .uri("/api/v1/portfolio")
                .header(HttpHeaders.HOST, ALLOWED_HOST)
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void whenHostIsNotAllowed_thenForbidden() {
        // O filtro vai barrar antes de chegar no MockWebServer
        webTestClient.get()
                .uri("/api/v1/portfolio")
                .header(HttpHeaders.HOST, "evil.com")
                .exchange()
                .expectStatus().isForbidden();
    }

    @Test
    void whenAiHostIsAllowed_thenHealth() {
        mockBackEnd.enqueue(new MockResponse().setResponseCode(200).setBody("ok"));

        webTestClient.get()
                .uri("/api/core/health")
                .header(HttpHeaders.HOST, ALLOWED_HOST)
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void whenHostIsAllowed_thenForwardPostTransaction() {
        mockBackEnd.enqueue(new MockResponse().setResponseCode(201));

        String json = "{\"ativo\":\"WEGE3\",\"tipo\":\"COMPRA\",\"quantidade\":50,\"precoUnitario\":38.90,\"dataOperacao\":\"2023-10-25\"}";

        webTestClient.post()
                .uri("/api/v1/portfolio/transactions")
                .header(HttpHeaders.HOST, ALLOWED_HOST)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated();
    }

    @Test
    void whenHostIsNotAllowed_thenForbiddenPostTransaction() {
        webTestClient.post()
                .uri("/api/v1/portfolio/transactions")
                .header(HttpHeaders.HOST, "evil.com")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{}")
                .exchange()
                .expectStatus().isForbidden();
    }

    @Test
    void whenHostIsAllowed_thenForwardDeleteTransaction() {
        mockBackEnd.enqueue(new MockResponse().setResponseCode(204));

        webTestClient.delete()
                .uri("/api/v1/portfolio/transactions/1")
                .header(HttpHeaders.HOST, ALLOWED_HOST)
                .exchange()
                .expectStatus().isNoContent();
    }
}